
=begin
intenté usar pero no pude lograr el método para dibujar 
    n = ARGV[0].to_i
    n.times do |i|
    print "*.."..,
=end

puts "A). Método letra_o(n)""\n"
print "
*****
*   *
*   *
*   *
*****" "\n""\n"

puts "B). Método letra_i(n)""\n"
print "
*****
  *
  *
  *
*****" "\n""\n"
puts "C). Método letra_z(n)""\n"
print "
*****
   *
 *
*
***** ""\n""\n"
puts "D). Método letra_x(n)""\n"
print "
*   *
 * *
  *
 * *
*   * ""\n""\n"

puts "E). Método numero_cero(n)""\n"
print "
*****
** *
* * *
* **
*****""\n""\n"

puts "F). Método navidad(n)" "\n"
print "
   *
  * *
 * * *
* * * *
   *
   *
 * * *" "\n" "\n"